
var GlobalDocumentos={
    url: 'http://localhost:3900/apiDocumentos/'
};


export default GlobalDocumentos;