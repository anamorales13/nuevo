
var Global={

    url: 'http://localhost:3900/apiErasmus/',
    urlprofesor: 'http://localhost:3900/apiProfesor/'
    
};


export default Global;