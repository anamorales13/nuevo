var GlobalProfesor={
    url: 'http://localhost:3900/apiProfesor/'
};


export default GlobalProfesor;