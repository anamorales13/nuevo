import React from 'react';

import './assets/css/App.css';
import Rutas from './Rutas';
import './index.css'
import Button from 'react-bootstrap/Button';

function App() {
  return (
    <div >     
     <Rutas/>
     
    </div>
    
  );
}

export default App;
